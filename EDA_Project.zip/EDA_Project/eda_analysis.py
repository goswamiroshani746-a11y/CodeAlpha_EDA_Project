import pandas as pd
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv("student_data.csv")

# Display first rows
print("First 5 Rows:")
print(df.head())

# Dataset information
print("\nDataset Info:")
print(df.info())

# Statistical summary
print("\nSummary Statistics:")
print(df.describe())

# Check missing values
print("\nMissing Values:")
print(df.isnull().sum())

# Average marks
df["Average"] = df[["Math", "Science", "English"]].mean(axis=1)

# Plot average marks
plt.figure(figsize=(6,4))
plt.bar(df["Student"], df["Average"])
plt.xlabel("Students")
plt.ylabel("Average Marks")
plt.title("Average Marks of Students")
plt.savefig("average_marks.png")

print("\nEDA Completed Successfully!")
