# Exploratory Data Analysis (EDA) Project

## Objective
Perform exploratory data analysis on a student dataset to identify trends, patterns, and insights.

## Tools Used
- Python
- Pandas
- Matplotlib

## Files Included
- eda_analysis.py
- student_data.csv
- README.md

## Analysis Performed
- Data structure exploration
- Summary statistics
- Missing value detection
- Average marks calculation
- Data visualization

## How to Run
1. Install libraries:
   pip install pandas matplotlib

2. Run:
   python eda_analysis.py
